﻿using System.Resources;
using System.Reflection;
using System.Runtime.InteropServices;
using MelonLoader;

[assembly: AssemblyTitle(emmVRCLoader.BuildInfo.Name)]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany(emmVRCLoader.BuildInfo.Company)]
[assembly: AssemblyProduct(emmVRCLoader.BuildInfo.Name)]
[assembly: AssemblyCopyright("Created by " + emmVRCLoader.BuildInfo.Author)]
[assembly: AssemblyTrademark(emmVRCLoader.BuildInfo.Company)]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("3a25f309-f002-4b35-a6f0-6b31f9a9c362")]
[assembly: AssemblyVersion(emmVRCLoader.BuildInfo.Version)]
[assembly: AssemblyFileVersion(emmVRCLoader.BuildInfo.Version)]
[assembly: NeutralResourcesLanguage("en")]
[assembly: MelonModInfo(typeof(emmVRCLoader.emmVRCLoader), emmVRCLoader.BuildInfo.Name, emmVRCLoader.BuildInfo.Version, emmVRCLoader.BuildInfo.Author, emmVRCLoader.BuildInfo.DownloadLink)]
[assembly: MelonModGameAttribute("VRChat", "VRChat")]